# android-google-cloud-translate
Example Android app using google-cloud-translate

**NOTES:**
- Before testing the app, replace `MainActivity.API_KEY` with your actual Translate API Key.
- This is by no means a real world application. I strongly discourage you from saving your API_KEY in plain sight.
